const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');

ffmpeg.setFfmpegPath(ffmpegPath);

const app = express();
const PORT = process.env.PORT || 5000;

const UPLOAD_DIR = path.join(__dirname, 'uploads');
const OUTPUT_DIR = path.join(__dirname, 'output');
[UPLOAD_DIR, OUTPUT_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

app.use(cors());
app.use(express.json());
app.use('/downloads', express.static(OUTPUT_DIR));

// In-memory job/file registry (swap for a DB if you need persistence across restarts)
const files = new Map(); // fileId -> { originalName, storedPath, meta }
const jobs = new Map(); // jobId -> { status, progress, outputPath, error }

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const id = uuidv4();
    const ext = path.extname(file.originalname);
    cb(null, `${id}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 * 1024 }, // 2GB cap, adjust as needed
  fileFilter: (req, file, cb) => {
    const allowed = /\.(mp4|mov|mkv|avi|webm|flv|wmv)$/i;
    if (!allowed.test(file.originalname)) {
      return cb(new Error('Unsupported file type'));
    }
    cb(null, true);
  },
});

// 1. Upload a video the user owns, and return metadata (duration, resolution, etc.)
app.post('/api/upload', upload.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  const fileId = uuidv4();
  const storedPath = req.file.path;

  ffmpeg.ffprobe(storedPath, (err, metadata) => {
    if (err) {
      fs.unlinkSync(storedPath);
      return res.status(500).json({ error: 'Could not read video metadata' });
    }

    const videoStream = metadata.streams.find((s) => s.codec_type === 'video');
    const info = {
      duration: metadata.format.duration,
      width: videoStream ? videoStream.width : null,
      height: videoStream ? videoStream.height : null,
      sizeBytes: metadata.format.size,
      format: metadata.format.format_name,
    };

    files.set(fileId, {
      originalName: req.file.originalname,
      storedPath,
      meta: info,
    });

    res.json({ fileId, originalName: req.file.originalname, meta: info });
  });
});

// Supported output qualities. Only downscaling is offered (upscaling gains nothing).
const QUALITY_HEIGHTS = { '360p': 360, '480p': 480, '720p': 720, '1080p': 1080 };

// 2. Start a conversion job for a previously uploaded file
app.post('/api/convert', (req, res) => {
  const { fileId, quality, format, audioOnly } = req.body;
  const fileEntry = files.get(fileId);
  if (!fileEntry) return res.status(404).json({ error: 'File not found. Upload it again.' });

  const jobId = uuidv4();
  const outExt = audioOnly ? (format === 'wav' ? 'wav' : 'mp3') : (format || 'mp4');
  const outputPath = path.join(OUTPUT_DIR, `${jobId}.${outExt}`);

  jobs.set(jobId, { status: 'processing', progress: 0, outputPath: null, error: null });

  let command = ffmpeg(fileEntry.storedPath);

  if (audioOnly) {
    command = command.noVideo().audioCodec(outExt === 'wav' ? 'pcm_s16le' : 'libmp3lame');
  } else {
    const targetHeight = QUALITY_HEIGHTS[quality];
    if (targetHeight && fileEntry.meta.height && targetHeight < fileEntry.meta.height) {
      command = command.videoFilter(`scale=-2:${targetHeight}`);
    }
    command = command.videoCodec('libx264').audioCodec('aac');
  }

  command
    .on('progress', (p) => {
      const job = jobs.get(jobId);
      if (job) job.progress = Math.min(99, Math.round(p.percent || 0));
    })
    .on('end', () => {
      const job = jobs.get(jobId);
      job.status = 'done';
      job.progress = 100;
      job.outputPath = outputPath;
    })
    .on('error', (err) => {
      const job = jobs.get(jobId);
      job.status = 'error';
      job.error = err.message;
    })
    .save(outputPath);

  res.json({ jobId });
});

// 3. Poll job status
app.get('/api/status/:jobId', (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({
    status: job.status,
    progress: job.progress,
    error: job.error,
    downloadUrl: job.status === 'done' ? `/downloads/${path.basename(job.outputPath)}` : null,
  });
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use((err, req, res, next) => {
  res.status(400).json({ error: err.message });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
