const API_BASE = window.REEL_API_BASE || 'http://localhost:5000';

const state = {
  file: null,
  fileId: null,
  meta: null,
  mode: 'video',
  quality: '480p',
  format: 'mp4',
};

const els = {
  dropzone: document.getElementById('dropzone'),
  fileInput: document.getElementById('fileInput'),
  browseBtn: document.getElementById('browseBtn'),
  fileCard: document.getElementById('fileCard'),
  fcName: document.getElementById('fcName'),
  fcDetails: document.getElementById('fcDetails'),
  fcRemove: document.getElementById('fcRemove'),
  options: document.getElementById('options'),
  modeRow: document.getElementById('modeRow'),
  qualityGroup: document.getElementById('qualityGroup'),
  qualityRow: document.getElementById('qualityRow'),
  formatRow: document.getElementById('formatRow'),
  convertBtn: document.getElementById('convertBtn'),
  progressCard: document.getElementById('progressCard'),
  progressStatus: document.getElementById('progressStatus'),
  progressPct: document.getElementById('progressPct'),
  progressBar: document.getElementById('progressBar'),
  resultCard: document.getElementById('resultCard'),
  downloadLink: document.getElementById('downloadLink'),
  convertAnother: document.getElementById('convertAnother'),
  errorCard: document.getElementById('errorCard'),
  errorText: document.getElementById('errorText'),
  errorRetry: document.getElementById('errorRetry'),
  historyList: document.getElementById('historyList'),
  clearHistory: document.getElementById('clearHistory'),
  themeToggle: document.getElementById('themeToggle'),
};

// ---------- Theme ----------
function initTheme() {
  const saved = localStorage.getItem('reel-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (saved === 'dark' || (!saved && prefersDark)) {
    document.documentElement.classList.add('dark');
  }
}
els.themeToggle.addEventListener('click', () => {
  document.documentElement.classList.toggle('dark');
  localStorage.setItem('reel-theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
});
initTheme();

// ---------- History (session-based, in-memory list rendered from localStorage) ----------
function loadHistory() {
  try {
    return JSON.parse(localStorage.getItem('reel-history') || '[]');
  } catch {
    return [];
  }
}
function saveHistory(list) {
  localStorage.setItem('reel-history', JSON.stringify(list));
}
function renderHistory() {
  const list = loadHistory();
  els.historyList.innerHTML = '';
  if (list.length === 0) {
    els.historyList.innerHTML = '<li class="history-empty">Nothing converted yet this session.</li>';
    return;
  }
  list.slice().reverse().forEach((item) => {
    const li = document.createElement('li');
    li.className = 'history-item';
    li.innerHTML = `
      <span>${item.name}</span>
      <span class="h-meta">${item.detail}</span>
      <a href="${item.url}" download>Download</a>
    `;
    els.historyList.appendChild(li);
  });
}
els.clearHistory.addEventListener('click', () => {
  saveHistory([]);
  renderHistory();
});
renderHistory();

// ---------- File selection ----------
function humanSize(bytes) {
  if (!bytes) return '';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(1)} ${units[i]}`;
}
function humanDuration(sec) {
  if (!sec) return '';
  const s = Math.round(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`
    : `${m}:${String(ss).padStart(2, '0')}`;
}

async function handleFile(file) {
  if (!file) return;
  state.file = file;
  resetPanels();
  els.fileCard.classList.remove('hidden');
  els.fcName.textContent = file.name;
  els.fcDetails.textContent = 'Reading file…';

  const formData = new FormData();
  formData.append('video', file);

  try {
    const res = await fetch(`${API_BASE}/api/upload`, { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload failed');

    state.fileId = data.fileId;
    state.meta = data.meta;
    els.fcDetails.textContent = `${humanDuration(data.meta.duration)} · ${data.meta.width}×${data.meta.height} · ${humanSize(data.meta.sizeBytes)}`;
    els.options.classList.remove('hidden');
    updateQualityAvailability();
  } catch (err) {
    els.fcDetails.textContent = 'Could not read this file.';
    showError(err.message);
  }
}

els.dropzone.addEventListener('click', () => els.fileInput.click());
els.browseBtn.addEventListener('click', (e) => { e.stopPropagation(); els.fileInput.click(); });
els.fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));

['dragenter', 'dragover'].forEach((evt) => {
  els.dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    els.dropzone.classList.add('drag-over');
  });
});
['dragleave', 'drop'].forEach((evt) => {
  els.dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    els.dropzone.classList.remove('drag-over');
  });
});
els.dropzone.addEventListener('drop', (e) => {
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});

els.fcRemove.addEventListener('click', () => {
  state.file = null;
  state.fileId = null;
  state.meta = null;
  els.fileInput.value = '';
  els.fileCard.classList.add('hidden');
  els.options.classList.add('hidden');
  resetPanels();
});

// ---------- Options ----------
function updateQualityAvailability() {
  if (!state.meta || !state.meta.height) return;
  const buttons = els.qualityRow.querySelectorAll('.pill');
  buttons.forEach((btn) => {
    const h = parseInt(btn.dataset.quality, 10);
    if (h > state.meta.height) {
      btn.disabled = true;
      btn.style.opacity = '0.4';
    } else {
      btn.disabled = false;
      btn.style.opacity = '1';
    }
  });
}

els.modeRow.addEventListener('click', (e) => {
  const btn = e.target.closest('.pill');
  if (!btn) return;
  state.mode = btn.dataset.mode;
  [...els.modeRow.children].forEach((c) => c.classList.toggle('active', c === btn));
  const isAudio = state.mode === 'audio';
  els.qualityGroup.classList.toggle('hidden', isAudio);
  els.formatRow.innerHTML = isAudio
    ? `<button class="pill active" data-format="mp3">MP3</button><button class="pill" data-format="wav">WAV</button>`
    : `<button class="pill active" data-format="mp4">MP4</button><button class="pill" data-format="webm">WebM</button>`;
  state.format = isAudio ? 'mp3' : 'mp4';
});

els.qualityRow.addEventListener('click', (e) => {
  const btn = e.target.closest('.pill');
  if (!btn || btn.disabled) return;
  state.quality = btn.dataset.quality;
  [...els.qualityRow.children].forEach((c) => c.classList.toggle('active', c === btn));
});

els.formatRow.addEventListener('click', (e) => {
  const btn = e.target.closest('.pill');
  if (!btn) return;
  state.format = btn.dataset.format;
  [...els.formatRow.children].forEach((c) => c.classList.toggle('active', c === btn));
});

// ---------- Convert ----------
function resetPanels() {
  els.progressCard.classList.add('hidden');
  els.resultCard.classList.add('hidden');
  els.errorCard.classList.add('hidden');
}

function showError(message) {
  resetPanels();
  els.errorText.textContent = message || 'Something went wrong.';
  els.errorCard.classList.remove('hidden');
}

els.convertBtn.addEventListener('click', async () => {
  if (!state.fileId) return;
  resetPanels();
  els.progressCard.classList.remove('hidden');
  els.progressStatus.textContent = 'Transcoding…';
  els.progressBar.style.width = '0%';
  els.progressPct.textContent = '0%';
  els.convertBtn.disabled = true;

  try {
    const res = await fetch(`${API_BASE}/api/convert`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileId: state.fileId,
        quality: state.quality,
        format: state.format,
        audioOnly: state.mode === 'audio',
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not start conversion');
    pollJob(data.jobId);
  } catch (err) {
    els.convertBtn.disabled = false;
    showError(err.message);
  }
});

function pollJob(jobId) {
  const interval = setInterval(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/status/${jobId}`);
      const data = await res.json();
      if (data.status === 'processing') {
        els.progressBar.style.width = `${data.progress}%`;
        els.progressPct.textContent = `${data.progress}%`;
      } else if (data.status === 'done') {
        clearInterval(interval);
        els.progressBar.style.width = '100%';
        els.progressPct.textContent = '100%';
        finishJob(data.downloadUrl);
      } else if (data.status === 'error') {
        clearInterval(interval);
        els.convertBtn.disabled = false;
        showError(data.error);
      }
    } catch (err) {
      clearInterval(interval);
      els.convertBtn.disabled = false;
      showError('Lost connection to the server.');
    }
  }, 1000);
}

function finishJob(downloadUrl) {
  els.convertBtn.disabled = false;
  resetPanels();
  const fullUrl = `${API_BASE}${downloadUrl}`;
  els.downloadLink.href = fullUrl;
  els.resultCard.classList.remove('hidden');

  const history = loadHistory();
  history.push({
    name: state.file.name,
    detail: state.mode === 'audio' ? `Audio (${state.format})` : `${state.quality} · ${state.format}`,
    url: fullUrl,
  });
  saveHistory(history.slice(-20));
  renderHistory();
}

els.convertAnother.addEventListener('click', () => {
  els.fcRemove.click();
});
els.errorRetry.addEventListener('click', () => {
  resetPanels();
});
