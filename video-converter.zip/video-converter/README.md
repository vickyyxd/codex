# Reel — convert your own videos

A small full-stack app for converting video files **you own or have the right to convert**. You upload a file, pick a quality or "audio only," and the server transcodes it with ffmpeg and hands back a download link.

It does not fetch, scrape, or download content from YouTube or any other third-party platform — everything it processes comes from a file the user chooses on their own device.

## Structure

```
video-converter/
├── server/          Express + ffmpeg backend
│   ├── index.js
│   ├── package.json
│   ├── uploads/      (created at runtime)
│   └── output/       (created at runtime)
└── public/           Static frontend (plain HTML/CSS/JS)
    ├── index.html
    ├── styles.css
    └── app.js
```

## Run it locally

**1. Backend**

```bash
cd server
npm install
npm start
```

This starts the API on `http://localhost:5000`. It uses `ffmpeg-static`, so you don't need ffmpeg installed system-wide.

**2. Frontend**

Just open `public/index.html` in a browser, or serve the folder statically:

```bash
cd public
npx serve .
```

If you deploy the frontend somewhere other than `localhost`, set the API location before `app.js` loads:

```html
<script>window.REEL_API_BASE = "https://your-backend-url.com";</script>
<script src="app.js"></script>
```

## How it works

1. **Upload** (`POST /api/upload`) — saves the file, runs `ffprobe` to read duration/resolution, returns a `fileId`.
2. **Convert** (`POST /api/convert`) — starts an ffmpeg job (video: scale + re-encode to H.264/AAC; audio-only: extract to MP3/WAV) and returns a `jobId`.
3. **Poll** (`GET /api/status/:jobId`) — frontend polls every second for progress; when done, returns a download URL served from `/downloads`.

## Notes on going to production

- Swap the in-memory `files`/`jobs` maps for Redis or a database if you need this to survive server restarts or scale across multiple instances.
- Add a cleanup job (cron or a TTL) to delete old files from `uploads/` and `output/`.
- Put the backend behind auth if it's not just for personal use — right now anyone who can reach the API can upload and convert.
- The 2GB upload limit and quality list (360p–1080p) are set in `server/index.js` — adjust `QUALITY_HEIGHTS` and multer's `limits.fileSize` as needed.

## Suggested hosting

- Frontend: Vercel, Netlify, or any static host.
- Backend: Render or Railway (needs a persistent-ish filesystem or attached storage for `uploads/`/`output/`, and enough CPU for ffmpeg).
